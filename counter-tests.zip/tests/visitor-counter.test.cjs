"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const createCounter = require("../visitor-counter.js");

function storage() {
    const values = new Map();
    return {
        getItem: key => values.has(key) ? values.get(key) : null,
        setItem: (key, value) => values.set(key, String(value)),
        removeItem: key => values.delete(key),
        values
    };
}
function fixture(extra = {}) {
    let clock = 1000000;
    const server = extra.server || { count: 0, requests: [] };
    const env = {
        localStorage: storage(), location: { hostname: "interpretingfc.com" },
        navigator: { userAgent: "Mozilla/5.0 Safari" },
        now: () => clock, setTimeout, clearTimeout, AbortController,
        fetch: async (url, opts) => {
            const operation = url.includes("/hit/") ? "hit" : "get";
            server.requests.push({ operation, url, opts });
            if (operation === "hit") { server.count++; }
            return { ok: true, status: 200, json: async () => ({ value: String(server.count) }) };
        },
        ...extra
    };
    return { env, server, counter: createCounter(env), advance: ms => { clock += ms; } };
}
const hits = f => f.server.requests.filter(r => r.operation === "hit").length;

test("a fresh browser counts once across refreshes and page navigation", async () => {
    const f = fixture();
    assert.equal((await f.counter.track()).count, 1);
    await f.counter.track();
    await createCounter(f.env).track();
    assert.equal(hits(f), 1);
    assert.equal(f.server.count, 1);
});
test("two browser profiles add two estimated visitors", async () => {
    const first = fixture();
    const second = fixture({ server: first.server });
    await first.counter.track();
    assert.equal((await second.counter.track()).count, 2);
});
test("concurrent calls in one instance dispatch one write", async () => {
    const f = fixture();
    const results = await Promise.all(Array.from({ length: 12 }, () => f.counter.track()));
    assert.ok(results.every(r => r.count === 1));
    assert.equal(hits(f), 1);
});
test("Web Locks serialize two tabs sharing browser storage", async () => {
    const f = fixture();
    let queue = Promise.resolve();
    f.env.navigator.locks = { request: (name, fn) => {
        queue = queue.then(fn);
        return queue;
    } };
    const tabA = createCounter(f.env), tabB = createCounter(f.env);
    await Promise.all([tabA.track(), tabB.track()]);
    assert.equal(hits(f), 1);
});
test("read-only stats refresh never increments", async () => {
    const f = fixture();
    await f.counter.read(); await f.counter.read();
    assert.equal(hits(f), 0);
    assert.equal(f.server.count, 0);
});
test("dashboard auto-initialization cannot count", async () => {
    const f = fixture({ document: { querySelector: selector => selector === "[data-counter-dashboard]" } });
    await f.counter.track();
    assert.equal(hits(f), 0);
});
test("owner exclusion persists and does not disable reads", async () => {
    const f = fixture();
    assert.equal(f.counter.setExcluded(true), true);
    await createCounter(f.env).track();
    assert.equal(hits(f), 0);
    assert.equal(f.server.requests.length, 1);
    assert.equal(f.counter.excluded(), true);
});
test("blocked or throwing browser storage never counts each page as a visitor", async () => {
    const f = fixture({ localStorage: {
        getItem() { throw Error("blocked"); }, setItem() { throw Error("blocked"); }
    } });
    await f.counter.track(); await f.counter.track();
    assert.equal(hits(f), 0);
    const env = { ...f.env };
    Object.defineProperty(env, "localStorage", { get() { throw Error("blocked getter"); } });
    await createCounter(env).track();
    assert.equal(hits(f), 0);
});
test("preview hosts make no external requests", async () => {
    const f = fixture({ location: { hostname: "localhost" } });
    assert.equal((await f.counter.track()).skipped, true);
    assert.equal(f.server.requests.length, 0);
});
test("automated crawlers only read", async () => {
    const f = fixture({ navigator: { userAgent: "Googlebot/2.1" } });
    await f.counter.track();
    assert.equal(hits(f), 0);
});
test("failed write creates no success marker; immediate retry is read-only", async () => {
    const f = fixture();
    const fetch = f.env.fetch;
    f.env.fetch = async (url, opts) => url.includes("/hit/")
        ? { ok: false, status: 503, json: async () => ({ error: "unavailable" }) }
        : fetch(url, opts);
    const failed = await f.counter.track();
    assert.equal(failed.live, false);
    assert.equal(failed.count, null);
    assert.ok(![...f.env.localStorage.values.keys()].some(k => k.endsWith(":counted")));
    f.env.fetch = fetch;
    await f.counter.track();
    assert.equal(hits(f), 0);
    f.advance(600001);
    await f.counter.track();
    assert.equal(hits(f), 1);
});
test("timeout is bounded, aborts request, and never fabricates zero", async () => {
    let signal;
    const f = fixture({ fetch: (url, opts) => {
        signal = opts.signal;
        return new Promise(() => {});
    } });
    const result = await createCounter(f.env, { timeoutMs: 5 }).track();
    assert.equal(signal.aborted, true);
    assert.equal(result.live, false);
    assert.equal(result.count, null);
});
test("malformed, noninteger, unsafe, missing and negative counts are rejected", async () => {
    for (const value of [null, undefined, "", false, "NaN", "1.5", "-1", "9007199254740992", "<script>"]) {
        const f = fixture({ fetch: async () => ({ ok: true, status: 200, json: async () => ({ value }) }) });
        assert.equal((await f.counter.read()).count, null, String(value));
    }
});
test("only the explicit missing-key response reads as zero", async () => {
    const f = fixture({ fetch: async () => ({ ok: false, status: 404, json: async () => ({ error: "Key not found" }) }) });
    assert.equal((await f.counter.read()).count, 0);
    f.env.fetch = async () => ({ ok: false, status: 404, json: async () => ({ error: "Not found" }) });
    const result = await fixture({ fetch: f.env.fetch }).counter.read();
    assert.equal(result.count, null);
    assert.equal(result.live, false);
});
test("an outage returns a dated cache, explicitly marked stale", async () => {
    const f = fixture();
    f.server.count = 42;
    await f.counter.read();
    f.advance(1000);
    f.env.fetch = async () => { throw Error("offline"); };
    const result = await f.counter.read();
    assert.equal(result.count, 42);
    assert.equal(result.live, false);
    assert.equal(result.checkedAt, 1000000);
});
test("numeric storage gets no cookies, referrer, form values or browser ID", async () => {
    const f = fixture();
    await f.counter.track();
    const { url, opts } = f.server.requests[0];
    assert.equal(opts.credentials, "omit");
    assert.equal(opts.referrerPolicy, "no-referrer");
    assert.equal(opts.mode, "cors");
    assert.equal(opts.cache, "no-store");
    assert.equal(opts.body, undefined);
    assert.equal(url, "https://countapi.mileshilliard.com/api/v1/hit/" + f.counter.key);
});
function dom() {
    const nodes = [];
    const make = tag => ({ tag, children: [], attributes: {},
        appendChild(node) { this.children.push(node); nodes.push(node); },
        setAttribute(key, value) { this.attributes[key] = value; } });
    const footer = make("footer");
    return { footer, querySelector: selector => selector === "footer" ? footer : null,
        getElementById: id => nodes.find(node => node.id === id),
        createElement: make, createTextNode: text => ({ textContent: text }) };
}
test("public footer hidden at 99, shown once at 100 in both languages", () => {
    const doc = dom(), f = fixture({ document: doc });
    f.counter.renderFooter({ count: 99, live: true });
    assert.equal(doc.footer.children.length, 0);
    f.counter.renderFooter({ count: 100, live: false });
    assert.equal(doc.footer.children.length, 0);
    f.counter.renderFooter({ count: 100, live: true });
    f.counter.renderFooter({ count: 100, live: true });
    assert.equal(doc.footer.children.length, 1);
    const line = doc.footer.children[0];
    assert.equal(line.children[0].className, "lang-en");
    assert.equal(line.children[1].className, "lang-es");
    assert.equal(line.children[0].children[1].textContent, "100");
});
