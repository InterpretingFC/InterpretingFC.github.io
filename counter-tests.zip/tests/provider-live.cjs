// Opt-in integration test. Uses an isolated random validation key, never production.
"use strict";
const { execFile } = require("node:child_process");
const { randomBytes } = require("node:crypto");
const assert = require("node:assert/strict");
const createCounter = require("../visitor-counter.js");
const key = "interpretingfc-validation-20261027-" + randomBytes(8).toString("hex");
const requests = [];
function fetchWithCurl(url, opts) {
    return new Promise((resolve, reject) => {
        execFile("curl", ["-sS", "-D", "-", "--max-time", "15", "-H",
            "Origin: https://interpretingfc.com", "-H", "Cache-Control: no-cache", url],
        { signal: opts.signal, maxBuffer: 1024 * 1024 }, (error, stdout) => {
            if (error) { reject(error); return; }
            const boundary = stdout.lastIndexOf("\r\n\r\n");
            const headers = stdout.slice(0, boundary), body = stdout.slice(boundary + 4);
            const statuses = [...headers.matchAll(/HTTP\/[\d.]+ (\d+)/g)];
            const status = Number(statuses[statuses.length - 1][1]);
            assert.match(headers, /access-control-allow-origin: https:\/\/interpretingfc\.com/i);
            requests.push({ operation: url.includes("/hit/") ? "hit" : "get", status });
            resolve({ ok: status >= 200 && status < 300, status, json: async () => JSON.parse(body) });
        });
    });
}
function browser() {
    const values = new Map();
    return createCounter({ fetch: fetchWithCurl, AbortController, setTimeout, clearTimeout,
        location: { hostname: "interpretingfc.com" }, navigator: { userAgent: "validation" },
        localStorage: { getItem: k => values.get(k) ?? null,
            setItem: (k, v) => values.set(k, v), removeItem: k => values.delete(k) }
    }, { key, timeoutMs: 16000 });
}
(async function () {
    const a = browser(), b = browser();
    const empty = await a.read();
    assert.equal(empty.live, true, JSON.stringify(empty));
    assert.equal(empty.count, 0);
    const first = await a.track();
    assert.equal(first.live, true, JSON.stringify(first));
    assert.equal(first.count, 1);
    assert.equal((await a.track()).count, 1, "refresh must only read");
    assert.equal((await b.track()).count, 2, "second browser must increment");
    assert.equal((await a.read()).count, 2);
    assert.equal((await b.read()).count, 2);
    assert.equal(requests.filter(r => r.operation === "hit").length, 2);
    console.log(JSON.stringify({ verifiedAt: new Date().toISOString(), key,
        result: "PASS", counts: [0, 1, 1, 2, 2, 2], requests,
        corsOrigin: "https://interpretingfc.com", productionKeyTouched: false }, null, 2));
}()).catch(error => { console.error(error); process.exitCode = 1; });
