"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const vm = require("node:vm");
const source = fs.readFileSync(require("node:path").join(__dirname, "../traffic.js"), "utf8");
const settle = () => new Promise(resolve => setImmediate(resolve));
function page(result, writable = true) {
    let excluded = false, reads = 0;
    const elements = new Map();
    const counter = {
        read: async () => { reads++; return result; },
        excluded: () => excluded,
        setExcluded: value => { excluded = value; return true; },
        storageWorks: () => writable
    };
    function element(id) {
        if (!elements.has(id)) {
            elements.set(id, { textContent: "", dataset: {}, disabled: false,
                listeners: {}, attributes: {},
                addEventListener(event, fn) { this.listeners[event] = fn; },
                setAttribute(key, value) { this.attributes[key] = value; }
            });
        }
        return elements.get(id);
    }
    vm.runInNewContext(source, { window: { IFCVisitorCounter: counter },
        document: { getElementById: element }, Date });
    return { element, reads: () => reads, excluded: () => excluded };
}
test("stats displays real zero as a successful live read", async () => {
    const p = page({ count: 0, checkedAt: 1793096800000, live: true });
    await settle();
    assert.equal(p.element("traffic-count").textContent, "0");
    assert.equal(p.element("traffic-status").dataset.state, "live");
    assert.equal(p.element("traffic-refresh").disabled, false);
});
test("unknown stats displays a dash and unavailable message", async () => {
    const p = page({ count: null, checkedAt: null, live: false });
    await settle();
    assert.equal(p.element("traffic-count").textContent, "—");
    assert.match(p.element("traffic-status").textContent, /unknown, not zero/);
    assert.equal(p.element("traffic-checked").textContent, "");
});
test("cached stats are explicitly stale and dated", async () => {
    const p = page({ count: 42, checkedAt: 1793096800000, live: false });
    await settle();
    assert.equal(p.element("traffic-count").textContent, "42");
    assert.match(p.element("traffic-status").textContent, /last saved count/);
    assert.match(p.element("traffic-checked").textContent, /Last successful check:/);
});
test("refresh calls only the read operation", async () => {
    const p = page({ count: 12, checkedAt: 1793096800000, live: true });
    await settle();
    await p.element("traffic-refresh").listeners.click();
    assert.equal(p.reads(), 2);
    assert.equal(p.element("traffic-count").textContent, "12");
});
test("owner exclusion toggle updates its saved state and label", async () => {
    const p = page({ count: 0, checkedAt: 1793096800000, live: true });
    await settle();
    p.element("traffic-toggle").listeners.click();
    assert.equal(p.excluded(), true);
    assert.match(p.element("traffic-exclusion").textContent, /excluded/);
    assert.equal(p.element("traffic-toggle").attributes["aria-pressed"], "true");
});
test("blocked storage has a clear status and disables the toggle", async () => {
    const p = page({ count: 0, checkedAt: 1793096800000, live: true }, false);
    await settle();
    assert.match(p.element("traffic-exclusion").textContent, /storage is blocked/);
    assert.equal(p.element("traffic-toggle").disabled, true);
});
